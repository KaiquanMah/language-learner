
import { Language, Lesson } from './types';

export const SUPPORTED_LANGUAGES: Language[] = [
  { code: 'es-ES', name: 'Spanish', voiceName: 'Google español' },
  { code: 'fr-FR', name: 'French', voiceName: 'Google français' },
  { code: 'de-DE', name: 'German', voiceName: 'Google Deutsch' },
  { code: 'it-IT', name: 'Italian', voiceName: 'Google italiano' },
  { code: 'ja-JP', name: 'Japanese', voiceName: 'Google 日本語' },
  { code: 'pt-BR', name: 'Portuguese', voiceName: 'Google português do Brasil' },
];

export const LESSON_CURRICULUM: Lesson[] = [
  {
    id: 'greetings',
    title: 'Greetings',
    emoji: '👋',
    prompt: 'Focus on basic greetings and introductions. Keep responses simple and suitable for a brand new learner.',
  },
  {
    id: 'numbers',
    title: 'Numbers & Counting',
    emoji: '🔢',
    prompt: 'Focus on numbers from 1-20, counting, and asking for prices. Use simple numerical questions.',
  },
  {
    id: 'food',
    title: 'Ordering Food',
    emoji: '🍕',
    prompt: 'Simulate a restaurant scenario. Focus on phrases for ordering food and drinks.',
  },
  {
    id: 'directions',
    title: 'Asking for Directions',
    emoji: '🗺️',
    prompt: 'Focus on basic questions and answers about locations and directions. Use simple landmark names.',
  },
  {
    id: 'daily_phrases',
    title: 'Daily Phrases',
    emoji: '🗣️',
    prompt: 'Cover common daily conversational phrases, like asking about someone\'s day or making small talk.',
  },
];
