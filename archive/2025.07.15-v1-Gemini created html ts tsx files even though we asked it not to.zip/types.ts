
export interface Language {
  code: string; // BCP 47 language tag e.g., 'es-ES'
  name: string;
  voiceName: string; // A representative voice name for Web Speech API
}

export interface Lesson {
  id: string;
  title: string;
  emoji: string;
  prompt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
}
