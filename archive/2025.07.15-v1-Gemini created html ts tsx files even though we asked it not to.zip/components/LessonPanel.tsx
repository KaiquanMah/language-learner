
import React from 'react';
import { Lesson } from '../types';

interface LessonPanelProps {
  lessons: Lesson[];
  currentLesson: Lesson;
  setCurrentLesson: (lesson: Lesson) => void;
  isLoading: boolean;
}

const LessonPanel: React.FC<LessonPanelProps> = ({ lessons, currentLesson, setCurrentLesson, isLoading }) => {
  return (
    <aside className="w-full md:w-72 bg-surface-light dark:bg-surface-dark p-6 rounded-xl shadow-lg h-full">
      <h2 className="text-2xl font-bold mb-6 text-text-light dark:text-text-dark">Lessons</h2>
      <nav>
        <ul>
          {lessons.map(lesson => (
            <li key={lesson.id} className="mb-2">
              <button
                onClick={() => setCurrentLesson(lesson)}
                disabled={isLoading}
                className={`w-full text-left p-4 rounded-lg text-lg transition-all duration-200 flex items-center space-x-4
                  ${currentLesson.id === lesson.id 
                    ? 'bg-primary-light dark:bg-primary-dark text-white font-semibold shadow-md' 
                    : 'text-text-secondary-light dark:text-text-secondary-dark hover:bg-gray-200 dark:hover:bg-gray-700 hover:text-text-light dark:hover:text-text-dark'
                  }
                  disabled:opacity-50 disabled:cursor-not-allowed`}
                aria-current={currentLesson.id === lesson.id}
              >
                <span className="text-2xl">{lesson.emoji}</span>
                <span>{lesson.title}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default LessonPanel;
