
import React, { useState, useEffect } from 'react';
import { MicrophoneIcon, SendIcon, SpinnerIcon } from './icons';

interface InputAreaProps {
  onSendMessage: (message: string) => void;
  isListening: boolean;
  startListening: () => void;
  stopListening: () => void;
  isLoading: boolean;
  transcript: string;
  setTranscript: (text: string) => void;
}

const InputArea: React.FC<InputAreaProps> = ({
  onSendMessage,
  isListening,
  startListening,
  stopListening,
  isLoading,
  transcript,
  setTranscript
}) => {
  const [textInput, setTextInput] = useState('');

  useEffect(() => {
    if (transcript) {
        setTextInput(transcript);
    }
  }, [transcript]);

  const handleSend = () => {
    if (textInput.trim() && !isLoading) {
      onSendMessage(textInput.trim());
      setTextInput('');
      setTranscript('');
    }
  };

  const handleMicClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="bg-surface-light dark:bg-surface-dark p-4 mt-4 rounded-xl shadow-lg flex items-center space-x-4">
      <button
        onClick={handleMicClick}
        disabled={isLoading}
        className={`p-4 rounded-full transition-all duration-300 ease-in-out text-white disabled:opacity-50
          ${isListening 
            ? 'bg-red-500 scale-110 shadow-lg' 
            : 'bg-primary-light dark:bg-primary-dark hover:bg-opacity-80'
          }`}
        aria-label={isListening ? 'Stop listening' : 'Start listening'}
      >
        <MicrophoneIcon className="w-8 h-8" />
      </button>
      <div className="relative flex-grow">
        <input
          type="text"
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? 'Listening...' : "Type or use the mic..."}
          disabled={isLoading || isListening}
          className="w-full bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark border-2 border-gray-300 dark:border-gray-600 rounded-full py-4 px-6 text-xl focus:ring-2 focus:ring-primary-light dark:focus:ring-primary-dark focus:border-transparent transition disabled:opacity-50"
        />
        {isLoading && (
            <div className="absolute right-16 top-1/2 -translate-y-1/2">
                <SpinnerIcon className="w-8 h-8 text-primary-light dark:text-primary-dark animate-spin" />
            </div>
        )}
      </div>
      <button
        onClick={handleSend}
        disabled={isLoading || !textInput.trim()}
        className="p-4 rounded-full bg-secondary-light dark:bg-secondary-dark text-white transition hover:bg-opacity-80 disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
        aria-label="Send message"
      >
        <SendIcon className="w-8 h-8" />
      </button>
    </div>
  );
};

export default InputArea;
