
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="text-center p-4 mt-auto text-text-secondary-light dark:text-text-secondary-dark">
      <p>
        <strong>Tip:</strong> Use the microphone for speaking practice or type your responses.
      </p>
      <p className="text-sm mt-2">
        Powered by React, Tailwind CSS, and the Google Gemini API.
      </p>
    </footer>
  );
};

export default Footer;
