
import React, { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
}

const ChatBubble: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const isAssistant = message.role === 'assistant';
  const bubbleClasses = isAssistant
    ? 'bg-primary-light dark:bg-primary-dark text-white self-start'
    : 'bg-gray-200 dark:bg-gray-700 text-text-light dark:text-text-dark self-end';

  const parts = message.text.split(/(\(.*?\))/g).filter(part => part);

  return (
    <div className={`w-fit max-w-lg rounded-2xl px-5 py-3 shadow ${bubbleClasses}`}>
        {parts.map((part, index) => {
            if (part.startsWith('(') && part.endsWith(')')) {
                return <p key={index} className="text-sm italic opacity-90 mb-1">{part.slice(1, -1)}</p>;
            }
            return <p key={index} className="text-lg">{part}</p>;
        })}
    </div>
  );
};

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex-1 bg-surface-light dark:bg-surface-dark p-6 rounded-xl shadow-lg flex flex-col h-full">
      <div className="flex-1 overflow-y-auto pr-4 space-y-4" aria-live="polite">
        {messages.map(msg => (
          <div key={msg.id} className="flex flex-col">
            <ChatBubble message={msg} />
          </div>
        ))}
         {isLoading && (
            <div className="flex justify-start">
                <div className="bg-primary-light dark:bg-primary-dark text-white self-start rounded-2xl px-5 py-3 shadow flex items-center space-x-2">
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                </div>
            </div>
        )}
        <div ref={endOfMessagesRef} />
      </div>
    </div>
  );
};

export default ChatWindow;
