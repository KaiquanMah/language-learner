
import React from 'react';
import { Language } from '../types';
import { SunIcon, MoonIcon } from './icons';

interface HeaderProps {
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  languages: Language[];
  currentLanguage: Language;
  setCurrentLanguage: (language: Language) => void;
  isLoading: boolean;
}

const Header: React.FC<HeaderProps> = ({ theme, setTheme, languages, currentLanguage, setCurrentLanguage, isLoading }) => {
  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedLang = languages.find(lang => lang.code === e.target.value);
    if (selectedLang) {
      setCurrentLanguage(selectedLang);
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <header className="bg-surface-light dark:bg-surface-dark shadow-md p-4 flex justify-between items-center fixed top-0 left-0 right-0 z-20">
      <h1 className="text-2xl font-bold text-primary-light dark:text-primary-dark">
        LinguaLearn
      </h1>
      <div className="flex items-center space-x-4">
        <div>
          <label htmlFor="language-select" className="sr-only">Choose a language</label>
          <select
            id="language-select"
            value={currentLanguage.code}
            onChange={handleLanguageChange}
            disabled={isLoading}
            className="bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-lg focus:ring-2 focus:ring-primary-light dark:focus:ring-primary-dark transition"
            aria-label="Select language to learn"
          >
            {languages.map(lang => (
              <option key={lang.code} value={lang.code}>
                {lang.name}
              </option>
            ))}
          </select>
        </div>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full text-text-light dark:text-text-dark hover:bg-gray-200 dark:hover:bg-gray-700 transition text-2xl"
          aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
        >
          {theme === 'light' ? <MoonIcon className="w-8 h-8"/> : <SunIcon className="w-8 h-8" />}
        </button>
      </div>
    </header>
  );
};

export default Header;
