
import React, { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Header from './components/Header';
import LessonPanel from './components/LessonPanel';
import ChatWindow from './components/ChatWindow';
import InputArea from './components/InputArea';
import Footer from './components/Footer';
import { useSpeech } from './hooks/useSpeech';
import { generateTutorResponse } from './services/geminiService';
import { SUPPORTED_LANGUAGES, LESSON_CURRICULUM } from './constants';
import { Language, Lesson, ChatMessage } from './types';

const App: React.FC = () => {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [currentLanguage, setCurrentLanguage] = useState<Language>(SUPPORTED_LANGUAGES[0]);
  const [currentLesson, setCurrentLesson] = useState<Lesson>(LESSON_CURRICULUM[0]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  const { isListening, transcript, startListening, stopListening, speak, setTranscript } = useSpeech(currentLanguage.code);

  const resetConversation = useCallback(() => {
    const welcomeText = `Welcome! Let's practice ${currentLesson.title} in ${currentLanguage.name}. You can start!`;
    const firstMessage: ChatMessage = {
        id: uuidv4(),
        role: 'system',
        text: welcomeText,
    };
    setMessages([firstMessage]);
    speak(welcomeText, currentLanguage.voiceName);
  }, [currentLanguage, currentLesson, speak]);
  
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove(theme === 'light' ? 'dark' : 'light');
    root.classList.add(theme);
  }, [theme]);
  
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    resetConversation();
  }, [currentLanguage, currentLesson]);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!text || isLoading) return;

    const userMessage: ChatMessage = { id: uuidv4(), role: 'user', text };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const responseText = await generateTutorResponse(newMessages, currentLanguage, currentLesson);
      const assistantMessage: ChatMessage = { id: uuidv4(), role: 'assistant', text: responseText };
      setMessages(prev => [...prev, assistantMessage]);
      speak(responseText, currentLanguage.voiceName);
    } catch (error) {
      console.error("Failed to get response:", error);
      const errorMessage: ChatMessage = { id: uuidv4(), role: 'system', text: "Sorry, an error occurred." };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, messages, currentLanguage, currentLesson, speak]);
  
  useEffect(() => {
      if(transcript && !isListening) {
          handleSendMessage(transcript);
          setTranscript('');
      }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [transcript, isListening]);


  return (
    <div className="min-h-screen flex flex-col font-sans bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark pt-24">
      <Header 
        theme={theme}
        setTheme={setTheme}
        languages={SUPPORTED_LANGUAGES}
        currentLanguage={currentLanguage}
        setCurrentLanguage={setCurrentLanguage}
        isLoading={isLoading}
      />
      <main className="flex-grow container mx-auto p-4 flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-1/3 lg:w-1/4">
            <LessonPanel
              lessons={LESSON_CURRICULUM}
              currentLesson={currentLesson}
              setCurrentLesson={setCurrentLesson}
              isLoading={isLoading}
            />
        </div>
        <div className="w-full md:w-2/3 lg:w-3/4 flex flex-col" style={{height: 'calc(100vh - 8rem)'}}>
          <ChatWindow messages={messages} isLoading={isLoading} />
          <InputArea
            onSendMessage={handleSendMessage}
            isListening={isListening}
            startListening={startListening}
            stopListening={stopListening}
            isLoading={isLoading}
            transcript={transcript}
            setTranscript={setTranscript}
          />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
