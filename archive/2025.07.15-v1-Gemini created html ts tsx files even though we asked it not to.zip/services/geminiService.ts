
import { GoogleGenAI } from "@google/genai";
import { ChatMessage, Language, Lesson } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function generateTutorResponse(
  messages: ChatMessage[],
  language: Language,
  lesson: Lesson
): Promise<string> {
  const model = "gemini-2.5-flash";

  const systemInstruction = `You are an expert language tutor AI named 'Lingua'. 
Your student is learning ${language.name}. 
The current lesson is about: "${lesson.title} - ${lesson.prompt}".
Your role is to engage in a simple, encouraging conversation in ${language.name}.
RULES:
1. ALWAYS respond in ${language.name}. Do not use English in your main response.
2. Keep your responses short, simple, and directly related to the lesson topic.
3. If the user makes a mistake, first provide a brief, helpful correction or suggestion in English inside parentheses, like this: (Quick tip: remember to use the formal 'usted' form here!). 
4. After the parenthetical correction, provide the correct and natural response in ${language.name}.
5. Be friendly and encouraging. Start the conversation if it's the beginning.`;
  
  const userMessages = messages.filter(m => m.role === 'user').map(m => m.text);
  const latestUserMessage = userMessages.length > 0 ? userMessages[userMessages.length - 1] : "Please start the conversation.";

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: [{ role: 'user', parts: [{ text: latestUserMessage }] }],
      config: {
        systemInstruction: systemInstruction,
      }
    });
    
    return response.text;
  } catch (error) {
    console.error("Error generating content from Gemini:", error);
    return "I'm sorry, I'm having trouble connecting. Please try again in a moment.";
  }
}
