import { useState, useEffect, useCallback, useRef } from 'react';

// --- Start: Added type definitions for Web Speech API ---

// These interfaces provide types for the non-standard Web Speech API,
// allowing TypeScript to compile without errors.

interface SpeechRecognitionAlternative {
    readonly transcript: string;
    readonly confidence: number;
}

interface SpeechRecognitionResult {
    readonly isFinal: boolean;
    readonly length: number;
    item(index: number): SpeechRecognitionAlternative;
    [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionResultList {
    readonly length: number;
    item(index: number): SpeechRecognitionResult;
    [index: number]: SpeechRecognitionResult;
}

// This event is fired when the speech recognition service returns a result.
interface SpeechRecognitionEvent extends Event {
    readonly resultIndex: number;
    readonly results: SpeechRecognitionResultList;
}

// This event is fired when a speech recognition error occurs.
interface SpeechRecognitionErrorEvent extends Event {
    readonly error: string;
    readonly message: string;
}

// This is the main interface for the speech recognition service instance.
interface ISpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    onstart: ((this: ISpeechRecognition, ev: Event) => any) | null;
    onend: ((this: ISpeechRecognition, ev: Event) => any) | null;
    onerror: ((this: ISpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
    onresult: ((this: ISpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
    start(): void;
    stop(): void;
}

// This is the type for the constructor (e.g., window.SpeechRecognition).
interface SpeechRecognitionStatic {
    new(): ISpeechRecognition;
}

// Extend the global Window interface to include the speech recognition constructors.
declare global {
    interface Window {
        SpeechRecognition: SpeechRecognitionStatic;
        webkitSpeechRecognition: SpeechRecognitionStatic;
    }
}
// --- End: Added type definitions ---


// Polyfill for cross-browser compatibility.
// Use a different variable name to avoid shadowing the type.
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;

export const useSpeech = (languageCode: string) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  // Use the defined interface for the ref type.
  const recognitionRef = useRef<ISpeechRecognition | null>(null);

  useEffect(() => {
    // Check against the API constructor variable.
    if (!SpeechRecognitionAPI) {
      console.warn('Speech Recognition API not supported in this browser.');
      return;
    }

    // Use the API constructor to create a new instance.
    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = languageCode;

    recognition.onstart = () => {
      setIsListening(true);
      setTranscript('');
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    // Explicitly type the event parameter.
    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
    };

    // Explicitly type the event parameter.
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const currentTranscript = event.results[0][0].transcript;
      setTranscript(currentTranscript);
    };
    
    recognitionRef.current = recognition;

    // Cleanup on component unmount
    return () => {
        recognition.stop();
    };
  }, [languageCode]);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening) {
      recognitionRef.current.start();
    }
  }, [isListening]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  }, [isListening]);

  const speak = useCallback((text: string, voiceName: string) => {
    if (!('speechSynthesis' in window)) {
        console.warn('Speech Synthesis API not supported in this browser.');
        return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = languageCode;
    
    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find(voice => voice.name === voiceName) || voices.find(voice => voice.lang === languageCode);

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    } else {
      console.warn(`Voice for language ${languageCode} not found. Using default.`);
    }

    window.speechSynthesis.cancel(); // Cancel any previous speech
    window.speechSynthesis.speak(utterance);
  }, [languageCode]);

  return { isListening, transcript, startListening, stopListening, speak, setTranscript };
};
