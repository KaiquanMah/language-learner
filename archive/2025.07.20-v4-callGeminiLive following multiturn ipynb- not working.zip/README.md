# Language Learner Web Application
This Language Learner web application is created for the last assignment in the Deep Learning course at the Y-DATA School of Data Science Bootcamp hosted in Tel Aviv, Israel.

**Issues remain to fix:**
1. Cannot record ourselves and check for pronunciation. 
2. Checking translation when typing - looks for exact patterns. It should be more flexible.
3. There is a mis-configuration between tabs - the current_topic in the session parameters is not updated so when moving to "practice" tab we are asked to choose a lesson first.
4. Progress bar issue
5. It will be nicer to have the user typing his own phrases to translate.
6. skip to main content button jumps or changes its location when it is pressed.
