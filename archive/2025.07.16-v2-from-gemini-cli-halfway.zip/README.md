# Language Learner Web Application
This Language Learner web application is created for the last assignment in the Deep Learning course at the Y-DATA School of Data Science Bootcamp hosted in Tel Aviv, Israel.
